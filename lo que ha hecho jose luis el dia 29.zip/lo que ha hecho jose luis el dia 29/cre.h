#ifdef creacioviaje-h
#define creacioviaje-h

#include <stdio.h>
#include <stdlib.h>
#include "stru


void creacioviaje(viaje* viaje);

#endif
