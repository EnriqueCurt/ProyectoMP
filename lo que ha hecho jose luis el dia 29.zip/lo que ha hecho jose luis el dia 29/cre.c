//esto lo ha realizado jose luis ramirez tocino
#include <stdio.h>
#include <time.h> // libreria de control del tiempo

int hora,minuto,dia,mes,a�o;
time_t now;

time(&now);

hora = local->tm_hour;         // obtener horas desde la medianoche (0-23)
minuto = local->tm_min;        // obtener minutos pasados despu�s de la hora (0-59)



dia = local->tm_mday;            // obtener el d�a del mes (1 a 31)
mes = local->tm_mon + 1;      // obtener el mes del a�o (0 a 11)
ano = local->tm_year + 1900;   // obtener el a�o desde 1900




struct viaje *crearvi;

crearvi=(struct viaje *)realloc(sizeof(struct viaje )* 1);

{ #comienzo del realloc

&crearvi[idviaje].idviaje=idviaje; # establece el idviaje

&crearvi[idviaje].plazas="campo plaza del fichero vehiculos"; # establece el numero de plazas disponibles segun el vehiculo selecionado

printf("pulse 1 para ida, pulse 2 para vuelta"); #pide que el usuario indique si el viaje es de ida o vuelta
scanf("$i",&crearvi[idviaje].idavuelta);


&crearvi[idviaje].estado="abierto"; # estabece por defecto el viaje como abierto

print("introduzca a�o"); #pide la fecha que el viaje !! hay que controlar que la fecha no sea del pasado!!
scanf("$i",&crearvi[idviaje].fecha.ano);
print("introduzca mes");
scanf("$i",&crearvi[idviaje].fecha.mes);
print("introduzca dia");
scanf("$i",&crearvi[idviaje].fecha.dia);

	   while(crearvi[idviaje].fecha.ano<ano){ # controlador a�o
	   printf("a�o no posible");
	   scanf("%i",);
	   }
	   if(crearvi[idviaje].fecha.ano=ano){
            while(crearvi[idviaje].fecha.mes<mes){ # controlador mes
            printf("mes no posible");
            scanf("%i",);
            }
        }

        if(crearvi[idviaje].fecha.ano=ano && crearvi[idviaje].fecha.mes=mes ){
            while(crearvi[idviaje].fecha.dia<dia){ # controlador dia
            printf("dia no posible");
            scanf("%i",);
            }
	   }

print("introduzca hora de salida"); #pide la hora de salida !! hay que controlar que la hora no haya pasado
scanf("$i",&crearvi[idviaje].horasalida.hora);
	   while(crearvi[idviaje].horasalida.hora>hora){ # controlador hora salida
	   printf("hora no posible");
	   scanf("%i",hora);
	   }

print("introduzca minuto de salida")
scanf("$i",&crearvi[idviaje].horasalida.minuto);
    if(crearvi[idviaje].horasalida.hora=hora){
            while(crearvi[idviaje].horasalida.minuto>minuto){ # controlador minuto salida
            printf("minuto no posible");
            scanf("%i",hora);
            }
    }

print("introduzca hora de llegada"); # pide la hora de llegada !! hay que controlar que sea mayor que la de salida
scanf("$i",&crearvi[idviaje].horallegada.hora);
	   while(crearvi[idviaje].horallegada.hora>hora){ # controlador hora salida
	   printf("hora no posible");
	   scanf("%i",hora);
	   }

print("introduzca minuto de llegada")
scanf("$i",&crearvi[idviaje].horallegada.minuto);
	   while(crearvi[idviaje].horallegada.minuto>minuto){ # controlador hora salida
	   printf("minuto no posible");
	   scanf("%i",hora);
	   }


printf("introduce precio total del viaje"); # pide el precio total del viaje
scanf("$f",&crearvi[idviaje].precio);

} #fin del realoc
//
